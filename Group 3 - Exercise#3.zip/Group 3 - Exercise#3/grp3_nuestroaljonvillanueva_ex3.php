<?php
// a) file_get_contents
$content = file_get_contents('http://aljon.com');
echo $content;

// b) file_put_contents()
$file = 'aljon.txt';
$data = 'Aljon V. Nuestro';

file_put_contents($file, $data);

// c) file_exists()
$file = 'aljon.txt';

if(file_exists($file)) {
    echo 'file exists.';
}
else {
    echo 'file does not exists.';
}

// d) file()
$file = 'aljon.txt';
$lines = file($file);

foreach ($lines as  $line) {
    echo $line . "<br>";
}

?>